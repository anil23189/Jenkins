import com.zapp.*

def call(body) {
    utils = new utilities()
    def pipelineParams= [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

	pipeline {
		
		agent {
			label "${pipelineParams.agent}"
		}
		
		environment {
			/**
			 * Tools version
			 */
			java_v = 'jdk-11.0.5'
			maven_v = 'Maven 3.6.1'
			settings_id = 'pwba-settings'	
			MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

			/**
			 * Application paths
			 */
			component="${pipelineParams.component}"
						
			/**
			 * Required User Credentials
			 */
			nexus_token = credentials('zapp.nexus.build.token')
			sonar_credentials = credentials('jenkins.sonarqube.token')
			git_credentials = credentials('zapp.jenkins.build')
		}
		
		options {
			buildDiscarder(logRotator(numToKeepStr: '4'))
			skipDefaultCheckout(true)
		}
		
		tools {
			maven pipelineParams.maven_v ?: maven_v
			jdk pipelineParams.java_v ?: java_v
		}
		
		stages {
			stage('Env Set Up') {
				steps {
					script {
						deleteDir()
						sh "mkdir ${component}"
					}
				}
			}

			stage('Checkout') {
				steps {
					dir ("${component}"){
						checkout scm
					}
					script{
						currentBuild.description = "Checking out ${component} from GIT"
					}
				}
			}
					
			stage('Build') {
				when {
					 anyOf { branch "${pipelineParams.branch}"; branch 'PR*'}
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn(pipelineParams.build_goal, settings_id)
						}
					}
				}
			}
										
			stage('Unit Tests') {
				when {
					expression { pipelineParams.test_goal != null }
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn(pipelineParams.test_goal, settings_id)
						}
					}
				}
			}

			stage('Integration Tests') {
				when {
					expression { pipelineParams.it_test_goal != null }
				}
				steps {
					dir ("${component}") {
						script {
							utils.mvn(pipelineParams.it_test_goal, settings_id)
						}
					}
				}
			}

			stage('Run Java Sonar') {
				when {
					expression { pipelineParams.sonar_goal != null }
				}
				tools {
					jdk 'jdk1.8_192'
				}
				steps {
					dir ("${component}") {
						script {
							withSonarQubeEnv("ZAPP_SonarQube") {
								utils.mvn(pipelineParams.sonar_goal, settings_id)
							}
						}
					}
				}
			}

			stage("Run Java Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 15, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage('Deploy to Nexus') {
				when {
					branch "${pipelineParams.branch}"
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn("clean deploy -DskipTests", settings_id)
						}
					}
				}
			}
		}		
	}        
}
