import com.zapp.*

def call(body) {
    utils = new utilities()
    def pipelineParams= [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()
	def flyway_modules_list = ""
    if(pipelineParams.flyway_modules){
        flyway_modules_list = pipelineParams.flyway_modules.join(",")
    }
	pipeline {
		
		agent {
			label "${pipelineParams.agent}"
		}
		
		parameters{
			string(name: 'deploy_util_version', defaultValue: '5.5.11', description: 'leave blank to take version from ansible vars')
			string(name: 'db_deploy_util_version', defaultValue: '', description: 'leave blank to take version from ansible vars')
			string(name: 'ansible_branch', defaultValue: 'master', description: 'leave blank to take version from ansible vars')
			string(name: 'generate_vulnerability_report', defaultValue: 'No', description: '')
		}
		
		environment {
			/**
			 * Tools version
			 */
			java_v = 'jdk1.7_151'
			JDK7u17_HOME = tool name: 'jdk1.7_17'
			maven_v = 'Maven 3.0.4'
			settings_id = 'pwba-settings'	
			MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

			/**
			 * Repo URLs
			 */
			ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"
		
			/**
			 * Application paths
			 */
			component="${pipelineParams.component}"
			/**
			 * Deploy utils
			 */			
			mw_deployment_util = "middleware-deployment-utility"
			db_deployment_util = "database-deployment-utility"		
			wlst_deployment_util = "wlst-deploy-utility"
			
			/**
			 * Environment paths
			 */
			ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
			PATH = "$PATH:$ORACLE_HOME/bin"
			db_test_dir = "$WORKSPACE/properties/test"
			config_path = "$WORKSPACE/properties/"
			sonar_scanner="/fs01/jenkins/tools/sonar-scanner-4.2.0.1873-linux/bin/sonar-scanner"
			vault_password_file = 'vault-password'
			/**
			 * Required User Credentials
			 */
			nexus_token = credentials('zapp.nexus.build.token')
			sonar_credentials = credentials('jenkins.sonarqube.token')
			git_credentials = credentials('zapp.jenkins.build')
			
		}
		
		options {
			buildDiscarder(logRotator(numToKeepStr: '4'))
			skipDefaultCheckout(true)
			disableConcurrentBuilds()
	
		}
		
		tools {
			maven pipelineParams.maven_v ?: maven_v
			jdk pipelineParams.java_v ?: java_v
		}
		
		stages {
			stage('Lock CB') {
				options {
					lock(resource: "${pipelineParams.component}-cb")
				}
				
				stages {				
					stage('Env Set Up') {
						steps {
							script {
								deleteDir()
								sh "mkdir ${component}"
								sh "mkdir ansible"
							}
						}
					}
					
					stage('Checkout') {
						steps {
							dir ("${component}"){
								checkout scm
							}
							script{
								currentBuild.description = ""
							}
						}
					}
					
					stage('Build') {
						
						when {
							 anyOf { branch "${pipelineParams.branch}"; branch 'PR*'}
						}
			
						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.build_goal, settings_id)
								}
							}					
						}
					}
					
					stage('Prepare Ansible') {				
						steps {
							script {
								mw_util = utils.utility_version(params.deploy_util_version, 'deploy_util_version')
								component_version = utils.version(component,settings_id)
							}
							dir ("$WORKSPACE/ansible") {	
								checkout([$class: 'GitSCM', 
									branches: [[name: params.ansible_branch]],
									doGenerateSubmoduleConfigurations: false, 
									extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
										[$class: 'SparseCheckoutPath', path: "/${component}/"], 
										[$class: 'SparseCheckoutPath', path: "/${mw_deployment_util}/roles/${mw_deployment_util}"], 
										[$class: 'SparseCheckoutPath', path: "/roles/${db_deployment_util}"]]							
									]],
									submoduleCfg: [],
									userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
								])					
									
								sh "mv $WORKSPACE/ansible/${mw_deployment_util}/roles/${mw_deployment_util} $WORKSPACE/ansible/roles/${db_deployment_util} $WORKSPACE/ansible/${component}/roles/"
								sh "rm -rf $WORKSPACE/ansible/${mw_deployment_util} $WORKSPACE/ansible/roles"
								sh "cp $WORKSPACE/${component}/properties/*.properties.j2 $WORKSPACE/ansible/${component}/roles/${component}/templates/ 2>/dev/null || :"
													
								dir ("$WORKSPACE/ansible/${component}") {
									script{
										utils.generate_password('zapp.ansible.vault', vault_password_file)
									}
									withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
										sh """
											ansible-playbook -i inv/hosts.yml ${component}.yml --vault-password-file ./${vault_password_file} -e flyway_modules="${flyway_modules_list}" \
											-e nexus_user=${git_credentials_usr} -e nexus_pass=${git_credentials_psw} -e key1=$apkeyfile -e ssh_user=$ssh_user -e env=${pipelineParams.env} -e workspace=$WORKSPACE \
											-e component_version=${component_version} -e component_name=${component} -e nexus_download="false" -e download_artifacts=false \
											$mw_util
											"""
									}
									script{
										utils.clean_confidential_data(vault_password_file)
									}
								}
							}
						}
					}
					
					stage('Deploy DB to CB11') {
						when {
							expression {
								return fileExists("$WORKSPACE/properties/flyway/db-deploy-config.properties")
							}
						}
						tools {
							jdk 'jdk1.8_192'
						}
						steps {
							script {
								utils.db_deploy(component,"$component/database",pipelineParams.env,pipelineParams.flyway_modules,"$WORKSPACE/properties/flyway")
							}
						}
					}
					stage('Unit Tests') {
						when {
							expression { pipelineParams.test_goal != null }
						}
						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.test_goal, settings_id)
								}
							}
						}
					}
					
					stage('Deploy App (Middleware Utility)')	{
						when {
							expression {
								return fileExists("$WORKSPACE/properties/config-deploy.properties")
							}
						}
						steps {
							dir ('ap-middleware-deployment-utility') {
								sh """
								./runAPUtil.sh -Dconfig_properties_url=$WORKSPACE/properties/config-deploy.properties
								"""
							}
						}
					}
					
					stage ("Deploy App (WLST)") {
						when {
							expression {
								return fileExists("$WORKSPACE/ansible/${component}/roles/${component}/templates/config-deploy-wlst.properties.j2")			
							}
						}
						stages() {					
							stage("Prepare WLST scripts"){
								steps {
									script {
										component_version = utils.version(component,settings_id)
									}
									dir ("$WORKSPACE/ansible") {
										checkout([$class: 'GitSCM', 
											branches: [[name: params.ansible_branch]],
											doGenerateSubmoduleConfigurations: false, 
											extensions: [
												[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [[$class: 'SparseCheckoutPath', path: "/${wlst_deployment_util}/"]]							
											]],
											submoduleCfg: [],
											userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
										])
									
										dir ("$WORKSPACE/ansible/${wlst_deployment_util}") {
											script{
												utils.generate_password('zapp.ansible.vault', vault_password_file)
											}
											withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
												sh """
													ansible-playbook -i inv/hosts.yml --vault-password-file ./${vault_password_file} wlst-deploy-utility.yml -e env=${pipelineParams.env} -e component_version=${component_version} -e workspace=$WORKSPACE\
													-e nexus_download="false" -e component_name=${component} -e component_target_path="$WORKSPACE/${component}/assembly"
												"""
											}
											script{
												utils.clean_confidential_data(vault_password_file)
											}
										}
									}
								}
							}
							
							stage("Deploy App (WLST)") {
								steps {
									dir ("scripts") {
									sh """
										chmod +x $WORKSPACE/scripts/wlst_deploy.sh
										./wlst_deploy.sh
									"""
									}
								}
							}
						}
					}
					
					stage('Integration Tests') {
						when {
							expression { pipelineParams.it_test_goal != null }
						}
						steps {
							dir ("${component}") {
								script {
									utils.mvn(pipelineParams.it_test_goal, settings_id)
								}
							}
						}
					}
					
					stage('Parallel stage for Incremental DB deploy') {
						when {
							branch 'develop'
						}
						parallel {                        

							stage('Deploy to CB12'){
								when {
									expression {
										return fileExists("${config_path}/cb/flyway/db-deploy-config-cb12.properties")			
									}
								}
								options {
									lock(resource: 'CB12_APMDM')
								}
								tools {
									jdk 'jdk1.8_192'
								}
								steps {
									script {
										utils.db_deploy(component,"$component/database","cb12",pipelineParams.flyway_modules,"$WORKSPACE/properties/cb/flyway")
									}
								}
							}
							
							stage('Deploy to CB31'){
								when {
									expression {
										return fileExists("${config_path}/cb/flyway/db-deploy-config-cb31.properties")			
									}
								}
								options {
									lock(resource: 'CB31_APMDM')
								}
								tools {
									jdk 'jdk1.8_192'
								}
								steps {
									script {
										utils.db_deploy(component,"$component/database","cb31",pipelineParams.flyway_modules,"$WORKSPACE/properties/cb/flyway")
									}
								}
							}      
							
							stage('Deploy to CB32'){
								when {
									expression {
										return fileExists("${config_path}/cb/flyway/db-deploy-config-cb32.properties")			
									}
								}
								options {
									lock(resource: 'CB32_APMDM')
								}
								tools {
									jdk 'jdk1.8_192'
								}
								steps {
									script {
										utils.db_deploy(component,"$component/database","cb32",pipelineParams.flyway_modules,"$WORKSPACE/properties/cb/flyway")
									}
								}
							}
							
							stage('Deploy to CB21'){
								when {
									expression {
										return fileExists("${config_path}/cb/flyway/db-deploy-config-cb21.properties")			
									}
								}
								options {
									lock(resource: 'CB21_APMDM')
								}
								tools {
									jdk 'jdk1.8_192'
								}
								steps {
									script {
										utils.db_deploy(component,"$component/database","cb21",pipelineParams.flyway_modules,"$WORKSPACE/properties/cb/flyway")
									}
								}
							}
							
							stage('Deploy to CB22') {
								when {
									expression {
										return fileExists("${config_path}/cb/flyway/db-deploy-config-cb22.properties")			
									}
								}
								options {
									lock(resource: 'CB22_APMDM')
								}
								tools {
									jdk 'jdk1.8_192'
								}
								steps {
									script {
										utils.db_deploy(component,"$component/database","cb22",pipelineParams.flyway_modules,"$WORKSPACE/properties/cb/flyway")
									}
								}
							}
							
						}
					}			
				}
			}

			stage('Run Java Sonar') {
				when {
					expression { pipelineParams.sonar_goal != null }
				}
				tools {
					jdk 'jdk1.8_192'
				}
				steps {
					dir ("${component}") {
						script {
							withSonarQubeEnv("ZAPP_SonarQube") {
								utils.mvn(pipelineParams.sonar_goal, settings_id)
							}
						}
					}
				}
			}

			stage("Run Java Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 30, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage('Run DB Sonar') {
				when {
					expression { pipelineParams.sonar_db_goal != null }
				}
				steps {
					dir ("${component}") {
						script {
							component_version = utils.version(component,settings_id)
							withSonarQubeEnv("ZAPP_SonarQube") {
								sh "${pipelineParams.sonar_db_goal} -Dsonar.projectVersion=${component_version}"
							}
						}
					}
				}
			}

			stage("Run DB Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_db_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 30, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}
			stage ('Vulnerability check'){
				when {
					allOf {
						branch "${pipelineParams.branch}"
						expression { 
							params.generate_vulnerability_report == 'Yes'
						}
						expression {
							return fileExists("$WORKSPACE/properties/sonatype-config.properties")
						}
					}	
				}
				steps {
					dir ("$WORKSPACE/properties"){
					script {
							utils.vulnerability_check('sonatype-config.properties')
						}								
					}
				}
			}
			stage('Deploy to Nexus') {
				when {
					branch "${pipelineParams.branch}"
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn("clean deploy -Pdev-test-env-v3 -DskipTests -Dweblogic.home=/home/devops/fmw/wlserver_10.3 -Dosb.home=/home/devops/fmw/osb", settings_id)
						}
					}
				}
			}
		}
		post {
			always {
				script{
					utils.clean_confidential_data('all')
				}
			}
		}		
	}        
}