@Library('zapp-utilities') _

import com.zapp.utilities

utils = new utilities()

pipeline {

    agent {
        label 'zapp-dev-env2'
    }

    environment {
        /**
         * Tools version
         */
        java_v = 'jdk1.7_151'
        JDK7u17_HOME = tool name: 'jdk1.7_17'
        maven_v = 'Maven 3.0.4'
        settings_id = 'pwba-settings'
        MAVEN_OPTS = "-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

        /**
         * Required User Credentials
         */
        git_credentials = credentials('zapp.jenkins.build')
    }
    parameters {
        string(
                name: 'component',
                defaultValue: '',
                description: 'Enter the component to be released For ex: ap-core'
        )
        string(
                name: 'release_branch',
                defaultValue: 'release/',
                description: 'Enter The branch to release from For ex: 21q1'
        )
        string(
                name: 'commit_id',
                defaultValue: '',
                description: 'Enter The commit id to release from For ex: 776f9692139'
        )
        string(
                name: 'release_version',
                defaultValue: '',
                description: ' Enter the version to be released (without snapshot). For ex: 1.0.0'
        )
        string(
                name: 'next_development_version',
                defaultValue: '',
                description: 'Enter next snapshot version for develop branch. Usually once in a PI. For ex:1.1.0-SNAPSHOT'
        )
        string(
                name: 'next_patch_version',
                defaultValue: '',
                description: 'Enter next development(snapshot) version for release branch. For ex: 1.0.1-SNAPSHOT'
        )

        choice(
                name: 'release_code',
                choices: ['Yes', 'No'],
                description: 'Select Yes when a released version is required. Select No while creating release branch snapshot version only. Usually once in a PI'
        )

    }

    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
        skipDefaultCheckout(true)
        disableConcurrentBuilds()
    }

    tools {
        maven params.maven_v ?: maven_v
        jdk params.java_v ?: java_v
    }

    stages {
        stage('Validate') {
            when {
                allOf {
                    expression { params.component == '' }
                    expression { params.release_version == '' }
                }
            }
            steps {
                script {
                    currentBuild.result = 'FAILED'
                    error('Aborting build due to invalid input')
                }
            }
        }


        stage('Checkout') {
            steps {
                deleteDir()
                git branch: 'develop', credentialsId: 'zapp.jenkins.build', url: "https://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
                sh "git init"
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git remote add bitbucket http://${GIT_USERNAME}:${GIT_PASSWORD}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
                }
                script {
                    check_branch_exists = sh(script: "git ls-remote --heads http://${git_credentials_usr}:${git_credentials_psw}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git ${params.release_branch} | wc -l", returnStdout: true)
                    echo "brach exists code: ${check_branch_exists} "
                }
            }
        }
        stage('Create release branch and update next development version of develop branch') {
            when {
                expression {
                    check_branch_exists = sh(script: "git ls-remote --heads http://${git_credentials_usr}:${git_credentials_psw}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git ${params.release_branch} | wc -l", returnStdout: true) trim()
                    return check_branch_exists == '0'
                }
            }
            steps {
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git checkout -b ${params.release_branch}"
                    sh "git push bitbucket ${params.release_branch}"
                    sh "git checkout develop"
                }
                script {
                    utils.mvn("-B versions:set -DnewVersion=${params.next_development_version} -P all,dev-env-v3 -e", settings_id)
                    utils.mvn("-B deploy -DskipTests -P all,dev-env-v3", settings_id)
                }
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git commit -am \'${params.component} updated  with next develepment version ${params.next_development_version}\'"
                    sh "git push bitbucket develop"
                }
            }
        }
        stage('Release and Create Tag ') {
            when {
                expression { params.release_code == 'Yes' }
            }
            steps {
                sh "git checkout ${params.release_branch}"
                script {
                    if (params.commit_id) {
                        sh "git checkout ${params.commit_id}"
                        release_commit_msg = "${params.component} Released with version ${params.release_version} and commit_id ${params.commit_id}"
                    } else {
                        release_commit_msg = "${params.component} Released with version ${params.release_version}"
                    }
                    utils.mvn("-B versions:set -DnewVersion=${params.release_version} -P all,dev-env-v3 -e", settings_id)
                    utils.mvn("-B clean install -DskipTests -P all,dev-env-v3 -e", settings_id)
                    utils.mvn("-B deploy -DskipTests -P all,dev-env-v3", settings_id)
                }
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git commit -am \'${release_commit_msg}\'"
                    sh "git tag -a ${params.release_version} -m \'${release_commit_msg}\'"
                }
                script {
                    if(params.commit_id) {
                        sh "git checkout ${params.release_branch}"
                        sh "git commit --allow-empty -am \'${release_commit_msg}\'"
                    }
                }
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git push bitbucket ${params.release_branch}"
                    sh "git push bitbucket ${params.release_version}"
                }
            }
        }
        stage('Update Next Patch Version') {
            when {
                allOf {
                    expression { params.release_code == 'Yes' }
                    expression { params.next_patch_version?.trim() }
                }
            }
            steps {
                script {
                    utils.mvn("-B versions:set -DnewVersion=${params.next_patch_version} -P all,dev-env-v3 -e", settings_id)
                    utils.mvn("-B clean install -DskipTests -P all,dev-env-v3 -e", settings_id)
                    utils.mvn("-B deploy -DskipTests -P all,dev-env-v3", settings_id)
                }
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git commit --allow-empty -am \'${params.component} Next patch version updated to ${params.next_patch_version}\'"
                    sh "git push bitbucket ${params.release_branch}"
                }
            }
        }
    }
}