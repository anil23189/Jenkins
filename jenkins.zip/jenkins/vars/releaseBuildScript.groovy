@Library('zapp-utilities') _

pipeline {

	agent {
		label 'zapp-dev-env2'
	}

	parameters{
		choice(
				name: 'component',
				choices: ['', 'jenkins', 'ansible'],
				description: 'Select the component to be released'
		)
		booleanParam(
				name: 'merge',
				defaultValue: 'false',
				description: 'Tick the box to merge changes from develop prior to release'
		)
		string(
				name: 'release_version',
				defaultValue: '',
				description: 'Please specify release version (for ex: 20q4)'
		)
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	stages {

		stage('Validate') {
			when {
				allOf {
					expression { params.component == '' }
					expression { params.release_version == '' }
				}
			}
			steps {
				script {
					currentBuild.result = 'FAILED'
					error('Aborting build due to invalid input')
				}
			}
		}

		stage('Checkout') {
			steps {
				deleteDir()
				git branch: "release/${params.release_version}", credentialsId: 'zapp.jenkins.build', url: "http://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git remote add bitbucket http://${GIT_USERNAME}:${GIT_PASSWORD}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
				}
			}
		}

		stage('Merge') {
			when {
				expression { params.merge == true }
			}
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git merge --ff-only origin/develop"
					sh "git push bitbucket release/${params.release_version}"
				}
			}
		}

		stage('Update tag') {
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git push bitbucket :refs/tags/${params.release_version}"
					sh "git tag -fa ${params.release_version} -m \'Released with version ${params.release_version}\'"
					sh "git push bitbucket ${params.release_version}"
				}
			}
		}

		stage('Update master') {
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git checkout master"
					sh "git merge --ff-only refs/tags/${params.release_version}"
					sh "git push bitbucket master"
				}
			}
		}
	}
}
