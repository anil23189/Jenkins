import com.zapp.*

def call(body) {
    utils = new utilities()
    def pipelineParams= [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = pipelineParams
    body()

	pipeline {
		
		agent {
			label "${pipelineParams.agent}"
		}
		
		parameters{
			string(name: 'ansible_branch', defaultValue: 'master', description: 'leave blank to take version from ansible vars')
		}
		
		environment {
			/**
			 * Tools version
			 */
			java_v = 'jdk-11.0.5'
			maven_v = 'Maven 3.6.1'
			settings_id = 'pwba-settings'	
			MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

			/**
			 * Repo URLs
			 */
			ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"
		
			/**
			 * Application paths
			 */
			component="${pipelineParams.component}"
						
			/**
			 * Environment paths
			 */
			ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
			PATH = "$PATH:$ORACLE_HOME/bin"
			db_test_dir = "$WORKSPACE/properties/test"
			config_path = "$WORKSPACE/properties/"
			sonar_scanner="/fs01/jenkins/tools/sonar-scanner-4.2.0.1873-linux/bin/sonar-scanner"
			vault_password_file = 'vault-password'
			/**
			 * Required User Credentials
			 */
			nexus_token = credentials('zapp.nexus.build.token')
			sonar_credentials = credentials('jenkins.sonarqube.token')
			git_credentials = credentials('zapp.jenkins.build')
		}
		
		options {
			buildDiscarder(logRotator(numToKeepStr: '4'))
			skipDefaultCheckout(true)
			disableConcurrentBuilds()
	
		}
		
		tools {
			maven pipelineParams.maven_v ?: maven_v
			jdk pipelineParams.java_v ?: java_v
		}
		
		stages {
			stage('Lock CB') {
				options {
					lock(resource: "${pipelineParams.component}-cb")
				}
				
				stages {				
					stage('Env Set Up') {
						steps {
							script {
								deleteDir()
								sh "mkdir ${component}"
								sh "mkdir ansible"
							}
						}
					}
					
					stage('Checkout') {
						steps {
							dir ("${component}"){
								checkout scm
							}
							script{
								currentBuild.description = ""
							}
						}
					}
					
					stage('Build') {
						
						when {
							 anyOf { branch "${pipelineParams.branch}"; branch 'PR*'}
						}
			
						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.build_goal, settings_id)
								}
							}					
						}
					}
										
					stage('Unit Tests') {
						when {
							expression { pipelineParams.test_goal != null }
						}
						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.test_goal, settings_id)
								}
							}
						}
					}

                    stage('Run Integration Tests') {
                        when {
                            expression { pipelineParams.it_test_goal != null }
                        }
                        stages {
                            stage('Deploy Application') {
                                steps {
                                    script {
                                        component_version = utils.version(component,settings_id)
                                    }
                                    dir ("$WORKSPACE/ansible") {
                                        checkout([$class: 'GitSCM',
                                                  branches: [[name: params.ansible_branch]],
                                                  doGenerateSubmoduleConfigurations: false,
                                                  extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
                                                          [$class: 'SparseCheckoutPath', path: "/${component}/"],
                                                          [$class: 'SparseCheckoutPath', path: "/roles/"]]
                                                               ]],
                                                  submoduleCfg: [],
                                                  userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
                                        ])

                                        dir ("$WORKSPACE/ansible/${component}") {
											script{
												utils.generate_password('zapp.ansible.vault', vault_password_file)
											}
                                            withCredentials([sshUserPrivateKey(credentialsId: "zapp-apdev2", keyFileVariable: "apkeyfile", passphraseVariable: "", usernameVariable: "ssh_user")]) {
                                                sh """
											ANSIBLE_ROLES_PATH=../roles:roles ansible-playbook -i inv/hosts.yml ${component}.yml --vault-password-file ./${vault_password_file} \
											-e env=${pipelineParams.env} \
											-e workspace=$WORKSPACE \
											-e nexus_user=${git_credentials_usr} \
											-e nexus_pass=${git_credentials_psw} \
											-e key1=$apkeyfile \
											-e ssh_user=$ssh_user \
											-e component_version=${component_version} \
											-e component=${component} \
											-e nexus_download='false'
										"""
                                            }
											script{
												utils.clean_confidential_data(vault_password_file)
											}
                                        }
                                    }
                                }
                            }

                            stage('Integration Tests') {
                                steps {
                                    dir ("${component}") {
                                        script {
                                            utils.mvn(pipelineParams.it_test_goal, settings_id)
                                        }
                                    }
                                }
                            }
                        }
                    }
				}
			}

			stage('Run Java Sonar') {
				when {
					expression { pipelineParams.sonar_goal != null }
				}
				tools {
					jdk 'jdk1.8_192'
				}
				steps {
					dir ("${component}") {
						script {
							withSonarQubeEnv("ZAPP_SonarQube") {
								utils.mvn(pipelineParams.sonar_goal, settings_id)
							}
						}
					}
				}
			}

			stage("Run Java Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 15, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage('Run DB Sonar') {
				when {
					expression { pipelineParams.sonar_db_goal != null }
				}
				steps {
					dir ("${component}") {
						script {
							component_version = utils.version(component,settings_id)
							withSonarQubeEnv("ZAPP_SonarQube") {
								sh "${pipelineParams.sonar_db_goal} -Dsonar.projectVersion=${component_version}"
							}
						}
					}
				}
			}

			stage("Run DB Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_db_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 15, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage('Deploy to Nexus') {
				when {
					branch "${pipelineParams.branch}"
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn("clean deploy -DskipTests", settings_id)
						}
					}
				}
			}
		}		
	}        
}