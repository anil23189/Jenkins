import com.zapp.*

def call(body) {
	utils = new utilities()
	def pipelineParams= [:]
	body.resolveStrategy = Closure.DELEGATE_FIRST
	body.delegate = pipelineParams
	body()
	def flyway_modules_list = ""
    if(pipelineParams.flyway_modules){
        flyway_modules_list = pipelineParams.flyway_modules.join(",")
    }
	pipeline {

		agent {
			label "${pipelineParams.agent}"
		}

		parameters{
			string(name: 'deploy_util_version', defaultValue: '5.5.11', description: 'leave blank to take version from ansible vars')
			string(name: 'db_deploy_util_version', defaultValue: '', description: 'leave blank to take version from ansible vars')
			string(name: 'ansible_branch', defaultValue: 'master', description: 'leave blank to take version from ansible vars')
			string(name: 'generate_vulnerability_report', defaultValue: 'No', description: '')
		}

		environment {
			/**
			 * Tools version
			 */
			java_v = 'jdk-11.0.5'
			maven_v = 'Maven 3.6.1'
			settings_id = 'pwba-settings'
			db_secret = credentials('db-secret')
			MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

			/**
			 * Repo URLs
			 */
			ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

			/**
			 * Application paths
			 */
			component="${pipelineParams.component}"

			/**
			 * Deploy utils
			 */
			db_deployment_util = "database-deployment-utility"

			/**
			 * Environment paths
			 */
			ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
			PATH = "$PATH:$ORACLE_HOME/bin"
			db_test_dir = "$WORKSPACE/properties/test"
			config_path = "$WORKSPACE/properties/"
			sonar_scanner="/fs01/jenkins/tools/sonar-scanner-4.2.0.1873-linux/bin/sonar-scanner"
			vault_password_file = 'vault-password'
			/**
			 * Required User Credentials
			 */
			nexus_token = credentials('zapp.nexus.build.token')
			sonar_credentials = credentials('jenkins.sonarqube.token')
			git_credentials = credentials('zapp.jenkins.build')
			
		}

		options {
			buildDiscarder(logRotator(numToKeepStr: '4'))
			skipDefaultCheckout(true)
			disableConcurrentBuilds()

		}

		tools {
			maven pipelineParams.maven_v ?: maven_v
			jdk pipelineParams.java_v ?: java_v
		}

		stages {
			stage('Lock CB') {
				options {
					lock(resource: "${pipelineParams.component}-cb-techR")
				}

				stages {
					stage('Env Set Up') {
						steps {
							script {
								deleteDir()
								sh "mkdir ${component}"
								sh "mkdir ansible"
							}
						}
					}

					stage('Checkout') {
						steps {
							dir ("${component}"){
								checkout scm
							}
							script{
								currentBuild.description = ""
							}
						}
					}

					stage('Build') {

						when {
							anyOf { branch "${pipelineParams.branch}"; branch 'PR*'}
						}

						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.build_goal, settings_id)
								}
							}
						}
					}

					stage('Prepare Ansible') {
						steps {
							script {
								db_util = utils.utility_version(params.db_deploy_util_version, 'ap_database_deployment_utility_version')
								component_version = utils.version(component,settings_id)
							}
							dir ("$WORKSPACE/ansible") {
								checkout([$class: 'GitSCM',
										  branches: [[name: params.ansible_branch]],
										  doGenerateSubmoduleConfigurations: false,
										  extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
												  [$class: 'SparseCheckoutPath', path: "/${component}/"],
												  [$class: 'SparseCheckoutPath', path: "/roles/"]]
													   ]],
										  submoduleCfg: [],
										  userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
							])

								sh "mv $WORKSPACE/ansible/roles/${db_deployment_util} $WORKSPACE/ansible/${component}/roles/"
								sh "rm -rf $WORKSPACE/ansible/${db_deployment_util}"
								sh "cp $WORKSPACE/${component}/properties/*.properties.j2 $WORKSPACE/ansible/${component}/roles/${component}/templates/ 2>/dev/null || :"

								dir ("$WORKSPACE/ansible/${component}") {
									script{
										utils.generate_password('zapp.ansible.vault', vault_password_file)
									}

									withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
										sh """
											ansible-playbook -i inv/hosts.yml ${component}-techR.yml --vault-password-file ./${vault_password_file} -e flyway_modules="${flyway_modules_list}" \
											-e nexus_user=${git_credentials_usr} -e nexus_pass=${git_credentials_psw} -e key1=$apkeyfile -e ssh_user=$ssh_user -e env=${pipelineParams.env} -e workspace=$WORKSPACE \
											-e component_version=${component_version} -e component_name=${component} -e nexus_download="false" -e download_artifacts=false \
											"""
									}
									script{
										utils.clean_confidential_data(vault_password_file)
									}
								}
							}
						}
					}

					stage('Deploy DB to DV31') {
						when {
							expression {
								return fileExists("$WORKSPACE/properties/flyway/db-deploy-config.properties")
							}
						}
						tools {
							jdk 'openjdk11.28'
						}
						steps {
							script {
								utils.db_deploy(component,"$component/database",pipelineParams.env,pipelineParams.flyway_modules,"$WORKSPACE/properties/flyway","full","No",pipelineParams.branch)
							}
						}
					}

					stage('Unit Tests') {
						when {
							expression { pipelineParams.test_goal != null }
						}
						steps {
							dir ("${component}"){
								script {
									utils.mvn(pipelineParams.test_goal, settings_id)
								}
							}
						}
					}

					stage('Run Integration Tests') {
						when {
							expression { pipelineParams.it_test_goal != null }
						}
						stages {

							stage('Deploy Application') {
								steps {
									script {
										component_version = utils.version(component, settings_id)

										pipelineParams.modules.each { module ->
											dir("$WORKSPACE/ansible") {

												dir("$WORKSPACE/ansible/${component}") {
													script {
														utils.generate_password('zapp.ansible.vault', vault_password_file)
													}

													withCredentials([sshUserPrivateKey(credentialsId: "zapp-apdev2", keyFileVariable: "apkeyfile", passphraseVariable: "", usernameVariable: "ssh_user")]) {

														sh """
											 echo  $module deployment in progress
                                             ANSIBLE_ROLES_PATH=../roles:roles ansible-playbook -i inv/hosts.yml $module-deploy-techR.yml --vault-password-file ./${vault_password_file} \
                                             -e env=${pipelineParams.env} -e db-secret=$db_secret  -e workspace=$WORKSPACE -e nexus_user=${git_credentials_usr} \
                                             -e nexus_pass=${git_credentials_psw} -e key1=$apkeyfile -e ssh_user=$ssh_user \
                                             -e component_version=${component_version} -e component=$module \
                                             -e nexus_download='false' 
                                         """
													}
													script {
														utils.clean_confidential_data(vault_password_file)
													}
												}
											}
										}
									}
								}
							}


							stage('Integration Tests') {
								steps {
									dir ("${component}") {
										script {
											utils.mvn(pipelineParams.it_test_goal, settings_id)
										}
									}
								}
							}
						}
					}
				}
			}

			stage('Run Java Sonar') {
				when {
					expression { pipelineParams.sonar_goal != null }
				}
				tools {
					jdk 'jdk1.8_192'
				}
				steps {
					dir ("${component}") {
						script {
							withSonarQubeEnv("ZAPP_SonarQube") {
								utils.mvn(pipelineParams.sonar_goal, settings_id)
							}
						}
					}
				}
			}

			stage("Run Java Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 15, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage('Run DB Sonar') {
				when {
					expression { pipelineParams.sonar_db_goal != null }
				}
				steps {
					dir ("${component}") {
						script {
							component_version = utils.version(component,settings_id)
							withSonarQubeEnv("ZAPP_SonarQube") {
								sh "${pipelineParams.sonar_db_goal} -Dsonar.projectVersion=${component_version}"
							}
						}
					}
				}
			}

			stage("Run DB Quality Gate") {
				when {
					allOf {
						expression { pipelineParams.sonar_db_goal != null }
						anyOf { branch 'PR*'}
					}
				}
				steps {
					timeout(time: 15, unit: 'MINUTES') {
						waitForQualityGate abortPipeline: true
					}
				}
			}

			stage ('Vulnerability check'){
				when {
					allOf {
						branch "${pipelineParams.branch}"
						expression { 
							params.generate_vulnerability_report == 'Yes'
						}
						expression {
							return fileExists("$WORKSPACE/properties/sonatype-config.properties")
						}
					}	
				}
				steps {
					dir ("$WORKSPACE/properties"){
					script {
							utils.vulnerability_check('sonatype-config.properties')
						}								
					}
				}
			}

			stage('Deploy to Nexus') {
				when {
					branch "${pipelineParams.branch}"
				}
				steps {
					dir ("${component}"){
						script {
							utils.mvn("clean deploy -DskipTests", settings_id)
						}
					}
				}
			}
		}
	}
}