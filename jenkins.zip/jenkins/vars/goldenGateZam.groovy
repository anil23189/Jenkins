@Library('zapp-utilities') _

import com.zapp.utilities
utils = new utilities()

pipeline {

	environment {
		/**
		 * Tools version
		 */
		java_v = 'jdk1.8_192'
		maven_v = 'Maven 3.0.4'
		settings_id = 'pwba-settings'

		/**
		 * Repo URLs
		 */
		
		ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

		/**
		 * Required User Credentials
		 */
		nexus_token = credentials('zapp.nexus.build.token')		
		git_credentials = credentials('zapp.jenkins.build')		
		
	}
	
	agent {
		label "${params.agent}"
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Env Set Up') {
			steps {
				script {
					deleteDir()
					sh "mkdir ansible"
				}
			}
		}

		stage('Deploy golden gate') {
			steps {
				script {			
					ansible_branch = params.ansible_branch ?: 'master'
				}
				dir ("$WORKSPACE/ansible") {
					checkout([$class: 'GitSCM', 
						branches: [[name: ansible_branch]],
						doGenerateSubmoduleConfigurations: false, 
						extensions: [
							[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
							[$class: 'SparseCheckoutPath', path: "/golden-gate/"]]						
						]],
						submoduleCfg: [],
						userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
					])
					
					dir ("$WORKSPACE/ansible/golden-gate") {
						withCredentials([
								sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user'),
								file(credentialsId: 'zapp.vault.passphrase.ctrld.env', variable: 'vault_key')
							]) {
							sh """
								ansible-playbook -i inv/hosts.yml golden-gate.yml --vault-password-file ${vault_key} -e env=${params.env} \
								-e workspace=$WORKSPACE -e targetEnv=${params.target_environment} \
								-e golden_gate_module=${params.golden_gate_module} -e maa_process_name_suffix=${params.maa_process_name_suffix} \
								-e GG_TRANLOG_SETUP=${params.gg_tranlog_setup} -e component=golden-gate \
								-e nexus_user=${git_credentials_usr} -e nexus_pass=${git_credentials_psw} \
								-e ETL_Deploy=${params.ETL_Deploy} -e MAA_Deploy=${params.MAA_Deploy} \
								-e MC_Deploy=${params.MC_Deploy} -e source_prefix=${params.source_prefix} \
								-e target_prefix=${params.target_prefix} -e gg_set_suffix=${params.gg_set_suffix} \
								-e etl_prefix=${params.etl_prefix} -e etl_replicate_source_prefix=${params.etl_replicate_source_prefix} \
								-e etl_replicate_target_prefix=${params.etl_replicate_target_prefix} -e maa_source_prefix=${params.maa_source_prefix} \
								-e maa_replicate_source_prefix=${params.maa_replicate_source_prefix} -e maa_replicate_target_prefix=${params.maa_replicate_target_prefix} \
								-e mc_source_prefix=${params.mc_source_prefix} -e mc_replicate_source_prefix=${params.mc_replicate_source_prefix} \
								-e mc_replicate_target_prefix=${params.mc_replicate_target_prefix} -e create_defgen=${params.create_defgen} \
								-e copy_defgen=${params.copy_defgen} -e goldengate_stopGG=${params.goldengate_stopGG} \
								-e goldengate_startGG=${params.goldengate_startGG} -e database_branch=${params.database_branch} \
								-e nexus_download=${params.nexus_download} -e nexus_repo_type=${params.nexus_repo_type} \
								-e ap_core_version=${params.ap_core_version} -e ap_mdm_core_version=${params.ap_mdm_core_version} \
								-e ap_pba_core_version=${params.ap_pba_core_version} -e ap_p2p_core_version=${params.ap_p2p_core_version} \
								-e bpx_core_version=${params.bpx_core_version} -e ap_batch_core_version=${params.ap_batch_core_version} \
								-e ap_security_version=${params.ap_security_version} -e append_gg_set_suffix=${params.append_gg_set_suffix} 
							"""
						}
					}
				}
			}
		}
	}
	post {
		always {
			script{
				utils.clean_confidential_data('all')
			}
		}
	}
}