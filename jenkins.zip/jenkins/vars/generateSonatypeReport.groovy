pipeline {

    parameters{
        choice(
                name: 'build_type',
                choices: ['', 'all', 'component'],
                description: 'Select build type'
        )

        string(
                name: 'override_versions',
                defaultValue: '',
                description: 'Optional field. Provide versions to be overridden, if "build_type" selected is "all". If not provided, latest release versions will be used.\n' +
                        'Format: [-e <ARTIFACT_ID_WITH_UNDERSCORE>_version=<VERSION>]\n' +
                        'Example: [-e ap_core_ear_version=1.0.0 -e ap_core_backoffice_ear_version=1.0.0 -e ap_pos_nfc_core_ear_version=1.2.0]'
        )

        string(
                name: 'group_id',
                defaultValue: '',
                description: 'Enter component group id. Mandatory if "build_type" selected is "component".\n' +
                        'Example: [com.ap.pos.nfc.core.assembly]'
        )

        string(
                name: 'artifact_id',
                defaultValue: '',
                description: 'Enter component artifact id. Mandatory if "build_type" selected is "component".\n' +
                        'Example: [ap-pos-nfc-core-ear]'
        )

        string(
                name: 'version',
                defaultValue: '',
                description: 'Enter component version. Mandatory if "build_type" selected is "component".\n' +
                        'Example: [1.0.0-SNAPSHOT]'
        )

        string(
                name: 'packaging',
                defaultValue: '',
                description: 'Enter component packaging. Mandatory if "build_type" selected is "component".\n' +
                        'Options: [ear|zip|war|jar]\n' +
                        'Example: [ear]'
        )

        string(
                name: 'sonatype_application_id',
                defaultValue: '',
                description: 'Enter sonatype application id. Mandatory if "build_type" selected is "component"\n' +
                        'Options: [AP_Core|AP_Core_Backoffice|AP_Core_Backend|BPX_CORE|AP_BPX_CSI|Adaptor|AP_POS_NFC_Core|AP_POS_NFC_BO_Core|AP_POS_NFC_REST_CORE|AP_VCN_CORE|AP_VCN_COMPOSITE|AP_PBA_CSI|AP_OPINS_SERVICE|AP_P2P_Core\n' +
                        '|Batch_Core|SAM|AP_MDM_Core|MDM_CSI|AP_MDM_COMPOSITE|Security_Verification|BAH_Crypto|MDES_Crypto|Security_cfi_crypto|Jose_Signing|PBAJOSESigningVerification|DigestSigning|DigestVerification|Symmetric_Crypto]\n' +
                        'Example: [AP_POS_NFC_Core]'
        )

        string(
                name: 'email_addresses',
                defaultValue: '',
                description: 'Enter comma separated email addresses'
        )

        string(
                name: 'ansible_branch',
                defaultValue: 'master',
                description: 'Enter the ansible branch'
        )
    }

    environment {

        /**
         * Environment paths
         */
        nexus_iq_cli_path = "$WORKSPACE/ansible/sonatype-reports/lib/nexus-iq-cli-1.96.0-01.jar"

        /**
         * Repo URLs
         */
        ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"
        nexus_iq_url = "http://nexus-iq.vocalink.co.uk"

        /**
         * Required User Credentials
         */
        nexus_token = credentials('zapp.jenkins.build')
        nexus_iq_credentials = credentials('zapp.service')
    }

    agent {
        label "ansible2.7"
    }

    options {
        buildDiscarder(logRotator(numToKeepStr: '5'))
        skipDefaultCheckout(true)
        disableConcurrentBuilds()
    }

    stages {

        stage('Validate') {
            when {
                not {
                    anyOf {
                        expression { build_type == 'all' }
                        allOf {
                            expression { build_type == 'component' }
                            expression { group_id?.trim() }
                            expression { artifact_id?.trim() }
                            expression { version?.trim() }
                            expression { packaging?.trim() }
                            expression { sonatype_application_id?.trim() }
                        }
                    }
                }
            }
            steps {
                script {
                    currentBuild.result = 'FAILED'
                    error('Aborting build due to invalid input')
                }
            }
        }

        stage('Env Set Up') {
            steps {
                script {
                    deleteDir()
                    sh "mkdir ansible"
                    sh "mkdir target"
                }
            }
        }

        stage('Download applications') {
            steps {
                dir ("$WORKSPACE/ansible") {
                    checkout([$class: 'GitSCM',
                              branches: [[name: ansible_branch]],
                              doGenerateSubmoduleConfigurations: false,
                              extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [[$class: 'SparseCheckoutPath', path: "/sonatype-reports/"]]]],
                              submoduleCfg: [],
                              userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
                    ])

                    dir ("sonatype-reports") {
                        ansiblePlaybook(
                                playbook: 'sonatype-reports.yml',
                                extraVars: [
                                        workspace: '$WORKSPACE',
                                        nexus_user: [value: '${git_credentials_usr}', hidden: true],
                                        nexus_pass: [value: '${git_credentials_psw}', hidden: true],
                                        build_type: [value: '${build_type}', hidden: false],
                                        group_id: [value: '${group_id}', hidden: false],
                                        artifact_id: [value: '${artifact_id}', hidden: false],
                                        version: [value: '${version}', hidden: false],
                                        extension: [value: '${packaging}', hidden: false],
                                        application_id: [value: '${sonatype_application_id}', hidden: false]
                                ],
                                extras: '${override_versions}'
                        )
                    }
                }
            }
        }

        stage('Evaluate Applications') {
            options {
                timeout(time: 30, unit: "MINUTES")
            }
            steps {
                dir ("$WORKSPACE/target/download"){
                    script {
                        applications = findFiles(glob: '*.*')
                        if(applications.size() <= 0) {
                            currentBuild.result = 'FAILED'
                            error('ERROR: Aborting build due to no components found for the evaluation, try re-running with correct input')
                        } else {
                            try {
                                applications.each { item ->
                                    application = "${item}"
                                    file_name = application.substring(0, application.lastIndexOf("."))
                                    id = file_name.substring(file_name.lastIndexOf("-") + 1)
                                    target = file_name.contains("-SNAPSHOT") ? 'build' : 'release'
                                    log_file = "../logs/${file_name}.json"
                                    sh """
								    java -Djava.net.useSystemProxies=false -jar $nexus_iq_cli_path -i $id -a $nexus_iq_credentials -s $nexus_iq_url -t $target -r $log_file $application || true
							    """
                                }
                            } catch (Throwable e) {
                                echo "ERROR: Failed to evaluate (try re-running) - ${e.toString()}"
                                currentBuild.result = "SUCCESS"
                            }
                        }
                    }
                }
            }
        }

        stage('Download Reports') {
            steps {
                dir ("$WORKSPACE/ansible/sonatype-reports/scripts"){
                    sh """
						./download_report.sh $WORKSPACE $nexus_iq_credentials
					"""
                }
            }
        }
    }

    post {
        success {
            script {
                if(email_addresses?.trim()) {
                    archiveArtifacts artifacts: 'target/reports/*.pdf',
                            onlyIfSuccessful: true

                    emailext attachmentsPattern: 'target/reports/*.pdf',
                            body: "${currentBuild.currentResult}: Job ${env.JOB_NAME} build ${env.BUILD_NUMBER}",
                            to: "${email_addresses}",
                            subject: "Jenkins Build ${currentBuild.currentResult}: Job ${env.JOB_NAME}"
                }
            }

        }
    }
}