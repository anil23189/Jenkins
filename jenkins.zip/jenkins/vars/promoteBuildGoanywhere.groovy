@Library('zapp-utilities') _

import com.zapp.utilities
utils = new utilities()

pipeline {
	agent {
		label "${params.agent}"
	}

	parameters{
		choice(name: 'gaw_action', choices: ['upload', 'deploy'], description: 'Choose action to be performed')
		string(name: 'component_version', defaultValue: '', description: 'Please enter version')
		string(name: 'branch', defaultValue: '', description: 'Please enter branch')
		string(name: 'commit', defaultValue: '', description: 'Please enter commit')
		string(name: 'target_environment', defaultValue: '', description: 'Please enter target environment')
		string(name: 'ansible_branch', defaultValue: 'master', description: 'Please enter ansible branch')
		string(name: 'agent', defaultValue: 'zapp-dev-env2', description: 'Please enter the agent')
		string(name: 'java_v', defaultValue: 'jdk1.8_192', description: 'Please specify the jdk')
		string(name: 'maven_v', defaultValue: 'Maven 3.6.1', description: 'Please specify the maven')
	}

	environment {
		component = 'ap-goanywhere'

		/**
		 * Tools version
		 */
		java_v = 'jdk1.8_192'
		maven_v = 'Maven 3.6.1'
		settings_id = 'pwba-settings'
		MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"

		/**
		 * Repo URLs
		 */
		component_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/${component}.git"
		ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

		/**
		 * Required User Credentials
		 */
		nexus_token = credentials('zapp.nexus.build.token')		
		git_credentials = credentials('zapp.jenkins.build')
		vault_password_file = 'vault-password'
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Validate') {
			when {
				not {
					allOf {
						expression { gaw_action?.trim() }
						anyOf {
							expression { branch?.trim() }
							expression { component_version?.trim() }
						}
						expression { target_environment?.trim() }
						expression { ansible_branch?.trim() }
					}
				}
			}
			steps {
				script {
					currentBuild.result = 'FAILED'
					error('Aborting build due to invalid input')
				}
			}
		}

		stage('Env Set Up') {
			steps {
				script {
					deleteDir()
					sh "mkdir ${component}"
					sh "mkdir ansible"
				}
			}
		}

		stage('Build') {
			when {
				expression { return params.branch }
			}
			steps {
				dir ("${component}"){
					git branch: "${params.branch}", credentialsId: 'zapp.jenkins.build', url: component_repo_url
					script {
						if (params.commit) {
							sh "git checkout ${params.commit}"
							currentBuild.description = "Deploy ${component} ${params.branch} : ${params.commit}"
						}
						else {
							currentBuild.description = "Deploy ${component} ${params.branch}"
						}
						utils.mvn("clean install -DskipTests", settings_id)
					}
				}
			}
		}

		stage('Deploy GoAnywhere') {
			steps {
				script {			
					component_version = params.component_version ?: ''
					ansible_branch = params.ansible_branch ?: 'master'
										
					if(!params.branch) {
						nexus = "-e nexus_download='true' -e component_version=${component_version}"
						currentBuild.description = "Deploy ${component} ${component_version}"
					} else {
						component_version = utils.version(component, settings_id)
						nexus = "-e nexus_download='false' -e component_version=${component_version}"
					}
				}
				dir ("$WORKSPACE/ansible") {
					checkout([$class: 'GitSCM', 
						branches: [[name: ansible_branch]],
						doGenerateSubmoduleConfigurations: false, 
						extensions: [
							[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
							[$class: 'SparseCheckoutPath', path: "/${component}/"]]
						]],
						submoduleCfg: [],
						userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
					])
					
					dir ("$WORKSPACE/ansible/${component}") {
						script{
							utils.generate_password('zapp.ansible.vault', vault_password_file)
						}
						withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
							sh """                    
								ansible-playbook -i inv/hosts.yml ${component}.yml \
									--vault-password-file ./${vault_password_file} \
									-e env=${params.target_environment} \
									-e workspace=$WORKSPACE \
									-e nexus_user=${git_credentials_usr} \
									-e nexus_pass=${git_credentials_psw} \
									-e component=${component} \
									-e gaw_action=${params.gaw_action} \
									$nexus
								"""
						}
						script{
							utils.clean_confidential_data(vault_password_file)
						}
					}
				}
			}
		}		
	}
	post {
		always {
			script{
				utils.clean_confidential_data('all')
			}
		}
	}
}