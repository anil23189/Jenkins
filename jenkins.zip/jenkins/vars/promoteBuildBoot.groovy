@Library('zapp-utilities') _

import com.zapp.utilities
utils = new utilities()

pipeline {

	environment {
		/**
		 * Tools version
		 */
		java_v = 'jdk-11.0.5'
		maven_v = 'Maven 3.6.1'
		settings_id = 'pwba-settings'

		/**
		 * Environment paths
		 */				
		ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
		PATH = "$PATH:$ORACLE_HOME/bin"
		db_test_dir = "${WORKSPACE}/properties/test"
		MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"
		vault_password_file = 'vault-password'
		/**
		 * Repo URLs
		 */
		component_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
		ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

		/**
		 * Required User Credentials
		 */
		nexus_token = credentials('zapp.nexus.build.token')		
		git_credentials = credentials('zapp.jenkins.build')
	}
	
	agent {
		label "${params.agent}"
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Env Set Up') {
			steps {
				script {
					deleteDir()
					sh "mkdir ${params.component}"
					sh "mkdir ansible"
				}
			}
		}

		stage('Build') {
			when {
				expression { return params.branch }
			}
			steps {
				dir ("${params.component}"){
					git branch: "${params.branch}", credentialsId: 'zapp.jenkins.build', url: component_repo_url
					script {
						if (params.commit) {
							sh "git checkout ${params.commit}"
							currentBuild.description = "Deploy ${params.component} ${params.commit}"
						}
						else {
							currentBuild.description = "Deploy ${params.component} ${params.branch}"
						}
						utils.mvn("clean install -DskipTests", settings_id)
					}
				}
			}
		}

		stage('Deploy Application') {
			steps {
				script {
					component_version = params.component_version ?: ''
					ansible_branch = params.ansible_branch ?: 'master'
					if(!params.branch) {
						nexus = "-e nexus_download='true' -e component_version=${component_version}"
						currentBuild.description = "Deploy ${params.component} ${component_version}"						
					} else {
						component_version = utils.version(params.component,settings_id)
						nexus = "-e nexus_download='false' -e component_version=${component_version}"
					}
				}
				
				dir ("$WORKSPACE/ansible") {	
					checkout([$class: 'GitSCM', 
						branches: [[name: params.ansible_branch]],
						doGenerateSubmoduleConfigurations: false, 
						extensions: [[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
							[$class: 'SparseCheckoutPath', path: "/${component}/"],
							[$class: 'SparseCheckoutPath', path: "/roles/"]]							
						]],
						submoduleCfg: [],
						userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
					])					
						
					dir ("$WORKSPACE/ansible/${params.component}") {
						script{
							utils.generate_password('zapp.ansible.vault', vault_password_file)
						}
						withCredentials([sshUserPrivateKey(credentialsId: "zapp-apdev2", keyFileVariable: "apkeyfile", passphraseVariable: "", usernameVariable: "ssh_user")]) {
							sh """
								ANSIBLE_ROLES_PATH=../roles:roles ansible-playbook -i inv/hosts.yml ${params.component}.yml --vault-password-file ./${vault_password_file} \
								-e env=${params.target_environment} \
								-e workspace=$WORKSPACE \
								-e nexus_user=${git_credentials_usr} \
								-e nexus_pass=${git_credentials_psw} \
								-e key1=$apkeyfile \
								-e ssh_user=$ssh_user \
								-e component=${component} \
								$nexus
							"""
						}
						script{
							utils.clean_confidential_data(vault_password_file)
						}
					}
				}
			}
		}
	}
}