@Library('zapp-utilities') _

import com.zapp.utilities
utils = new utilities()

pipeline {

	environment {
		/**
		 * Tools version
		 */
		java_v = 'jdk-11.0.5'
		maven_v = 'Maven 3.6.1'
		settings_id = 'pwba-settings'
		//modules = 'ap-mdm-core'

		/**
		 * Environment paths
		 */
		ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
		PATH = "$PATH:$ORACLE_HOME/bin"
		db_test_dir = "$WORKSPACE/properties/test"
		MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"
		vault_password_file = 'vault-password'
		/**
		 * Repo URLs
		 */
		component_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
		ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

		/**
		 * Deploy utils
		 */
		db_deployment_util = "database-deployment-utility"

		/**
		 * Required User Credentials
		 */
		nexus_token = credentials('zapp.nexus.build.token')
		git_credentials = credentials('zapp.jenkins.build')

	}

	agent {
		label "${params.agent}"
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Env Set Up') {
			steps {
				script {
					deleteDir()
					sh "mkdir ${params.component}"
					sh "mkdir ansible"
				}
			}
		}

		stage('Build') {
			when {
				expression { return params.branch }
			}
			steps {
				dir ("${params.component}"){
					git branch: "${params.branch}", credentialsId: 'zapp.jenkins.build', url: component_repo_url
					script {
						if (params.commit) {
							sh "git checkout ${params.commit}"
							currentBuild.description = "Deploy ${params.component} ${params.commit}"
						}
						else {
							currentBuild.description = "Deploy ${params.component} ${params.branch}"
						}
						utils.mvn("clean install -Pall,dev-env-v3,jenkins,dev-test-env-v3-digital,dev-test-env-v4-pbba,update-dev-timeout,release-app -DskipTests -Dsun.lang.ClassLoader.allowArraySyntax=true -Dbuild-test-stub -Dweblogic.home=/home/devops/fmw/wlserver_10.3 -Dosb.home=/home/devops/fmw/osb", settings_id)
					}
				}
			}
		}

		stage('Prepare Ansible') {
			steps {
				script {
					component_version = params.component_version ?: ''
					ansible_branch = params.ansible_branch ?: 'master'
					deploy_path = params.deploy_path ?: '/fs01/app/adapter-deployment/backoffice-sprint-test/zapp-client-adaptor'
					db_util = utils.utility_version(params.db_deploy_util_version?: '', 'ap_database_deployment_utility_version')

					if(!params.branch) {
						nexus = "-e nexus_download='true' -e component_version=${component_version}"
						currentBuild.description = "Deploy ${params.component} ${component_version}"
					} else {
						component_version = utils.version(params.component,settings_id)
						nexus = "-e nexus_download='false' -e component_version=${component_version}"
					}
				}
				dir ("$WORKSPACE/ansible") {
					checkout([$class: 'GitSCM',
							  branches: [[name: ansible_branch]],
							  doGenerateSubmoduleConfigurations: false,
							  extensions: [
									  [$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
											  [$class: 'SparseCheckoutPath', path: "/${params.component}/"],
											  [$class: 'SparseCheckoutPath', path: "/${db_deployment_util}/roles/${db_deployment_util}"],
											  [$class: 'SparseCheckoutPath', path: "/roles/"]]
									  ]],
							  submoduleCfg: [],
							  userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
					])


					sh "mv $WORKSPACE/ansible/${db_deployment_util}/roles/${db_deployment_util} $WORKSPACE/ansible/${component}/roles/"
					sh "rm -rf $WORKSPACE/ansible/${db_deployment_util}"
					sh "cp $WORKSPACE/${component}/properties/*.properties.j2 $WORKSPACE/ansible/${component}/roles/${component}/templates/ 2>/dev/null || :"

					dir ("$WORKSPACE/ansible/${params.component}") {
						withCredentials([string(credentialsId: 'e167fd61-3d4e-460f-9655-4384e02915db', variable: 'passphrase')]) {
							sh "touch vault-password"
							sh "echo ${passphrase} > vault-password"
						}
						withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev2', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
							sh """                    
									ansible-playbook -i inv/hosts.yml ${params.component}-techR.yml --vault-password-file ./${vault_password_file} -e env=${params.target_environment} -e workspace=$WORKSPACE \
									-e nexus_user=${git_credentials_usr} -e nexus_pass=${git_credentials_psw} -e download_artifacts=false -e nexus_download="false" \
									-e key1=$apkeyfile -e component_version=${component_version} -e ssh_user=$ssh_user -e deploy_path=${deploy_path} -e component_name=${params.component} \
									-e properties_version=${params.properties_version} \
								"""
						}
						script{
							utils.clean_confidential_data(vault_password_file)
						}
					}
				}
			}
		}

		stage('Deploy DB ') {
			when {
				expression {
					return fileExists("$WORKSPACE/properties/flyway/db-deploy-config.properties")
				}
			}
			tools {
				jdk 'openjdk11.28'
			}
			steps {
				script {
					def db_modules = flyway_modules.split(',')
					execute_checksum = params.execute_checksum ?: 'No'
					utils.db_deploy_promote(component,params.target_environment,db_modules,params.flyway_buildtype,execute_checksum,params.branch)
				}
			}
		}

		stage('Deploy apps ') {
			steps {
				script {
					component_version = utils.version(component, settings_id)

					def app_modules = modules.split(',')
					app_modules.each { module ->
						dir("$WORKSPACE/ansible") {
							dir("$WORKSPACE/ansible/${component}") {
								withCredentials([string(credentialsId: 'e167fd61-3d4e-460f-9655-4384e02915db', variable: 'passphrase')]) {
							sh "touch vault-password"
							sh "echo ${passphrase} > vault-password"
						}

								withCredentials([sshUserPrivateKey(credentialsId: "zapp-apdev2", keyFileVariable: "apkeyfile", passphraseVariable: "", usernameVariable: "ssh_user")]) {
									sh """
									echo  $module deployment in progress
                                     ANSIBLE_ROLES_PATH=../roles:roles ansible-playbook -i inv/hosts.yml $module-deploy-techR.yml --vault-password-file ./${vault_password_file} --tags "spring-boot-deploy" \
									-e env=${params.target_environment} -e module=$module -e workspace=$WORKSPACE -e nexus_user=${git_credentials_usr} \
									-e nexus_pass=${git_credentials_psw} -e key1=$apkeyfile -e ssh_user=$ssh_user \
									-e component_version=${component_version} -e component=${component} -e nexus_download='false' \
								"""
								}
								script {
									utils.clean_confidential_data(vault_password_file)
								}
							}
						}
					}
				}								}
		}
	}
	post {
		always {
			script{
				utils.clean_confidential_data('all')
			}
		}
	}
}