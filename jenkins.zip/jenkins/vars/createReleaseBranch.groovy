@Library('zapp-utilities') _
import com.zapp.utilities
utils = new utilities()
pipeline {

    parameters {
        string(name: 'component', defaultValue:'', description: 'Component name to create release branch from')
        string(name: 'release_branch_name', defaultValue:'', description: 'Name of the release branch without prefix (ex: 21q1)')
        string(name: 'next_release_version', defaultValue:'', description: 'Next development version for release branch')
        string(name: 'next_develop_version', defaultValue:'', description: 'Next development version for develop branch')
        string(name: 'settings_file', defaultValue: 'pwba-settings', description: 'The settings.xml file to be used')
        string(name: 'comment_prefix', defaultValue: 'AP-POS-NFC Core: ', description: 'The commit prefix')
        string(name: 'maven_v', defaultValue: 'Maven 3.0.4', description: '')
        string(name: 'java_v', defaultValue: 'jdk1.7_17', description: '')

    }

    environment {
        settings_id = "${params.settings_file}"
        git_credentials = credentials('zapp.jenkins.build')
    }

    agent {
        label 'zapp-dev-env'
    }

    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))
        skipDefaultCheckout(true)
        disableConcurrentBuilds()
    }

    tools {
        maven "${params.maven_v}"
        jdk "${params.java_v}"
    }

    stages {

        stage('Checkout the source branch to create release branch') {
            steps {
                deleteDir()
                git branch: "develop", credentialsId: 'zapp.jenkins.build', url: "http://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
                script{
                    currentBuild.description = "Checking out repo ${params.component} and branch develop"
                }
            }
        }

        stage('Create branch') {
            steps {
                script {
                    sh "git checkout -b release/${params.release_branch_name}"
                }
            }
        }

        stage('Update release branch module versions to next development version') {
            steps {
                script {
                    utils.mvn("-B versions:set -DnewVersion=${params.next_release_version} -P all,dev-env-v3 -e", settings_id)
                }
            }
        }

        stage('Commit and Push created branch') {
            steps {
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git remote add bitbucket http://${GIT_USERNAME}:${GIT_PASSWORD}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
                    sh "git commit -am \'${params.comment_prefix} Next development version updated to ${params.next_release_version}\'"
                    sh "git push bitbucket release/${params.release_branch_name}"
                }
            }
        }

        stage('Update develop branch modules to the next development version') {
            steps {
                script {
                    sh "git checkout develop"
                    utils.mvn("-B versions:set -DnewVersion=${params.next_develop_version} -P all,dev-env-v3 -e", settings_id)
                }
            }
        }

        stage('Commit and Push the new development version to develop') {
            steps {
                withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
                    sh "git commit -am \'${params.component} Next development version updated to ${params.next_develop_version}\'"
                    sh "git push bitbucket develop"
                }
            }
        }

    }
}