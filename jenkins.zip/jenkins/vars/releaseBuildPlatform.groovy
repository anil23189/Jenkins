@Library('zapp-utilities') _
import com.zapp.utilities
utils = new utilities()

pipeline {

	agent {
		label 'zapp-dev-env'
	}

	parameters{
		string(
				name: 'component',
				defaultValue: '',
				description: 'Enter the component to be released'
		)
		booleanParam(
				name: 'merge',
				defaultValue: 'false',
				description: 'Tick the box to merge changes from develop prior to release'
		)
		string(
				name: 'release_branch',
				defaultValue: '',
				description: 'Please specify release branch (for ex: 20q4)'
		)
		string(
				name: 'release_version',
				defaultValue: '',
				description: 'Please specify release version (for ex: 1.0.0)'
		)
		string(
				name: 'next_patch_version',
				defaultValue: '',
				description: 'Please specify next patch version (for ex: 1.0.0.1-SNAPSHOT)'
		)
		string(
				name: 'next_develop_version',
				defaultValue: '',
				description: 'Please specify next develop version (for ex: 1.0.1-SNAPSHOT). This is required only if merge option above is chosen'
		)
		string(
				name: 'java_v',
				defaultValue: 'openjdk11.28',
				description: 'Please specify the jdk'
		)
		string(
				name: 'maven_v',
				defaultValue: 'Maven 3.6.1',
				description: 'Please specify the maven'
		)
	}

	environment {
		/**
		 * Tools version
		 */
		java_v = 'jdk-11.0.5'
		maven_v = 'Maven 3.6.1'
		settings_id = 'pwba-settings'
		MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Validate') {
			when {
				allOf {
					expression { params.component == '' }
					expression { params.release_branch == '' }
					expression { params.release_version == '' }
					expression { params.next_patch_version == '' }
					expression { params.next_develop_version == '' }
				}
			}
			steps {
				script {
					currentBuild.result = 'FAILED'
					error('Aborting build due to invalid input')
				}
			}
		}

		stage('Checkout') {
			steps {
				deleteDir()
				script {
					try {
						git branch: "release/${params.release_branch}", credentialsId: 'zapp.jenkins.build', url: "https://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
					} catch (err) {
						currentBuild.result = 'FAILED'
						error('Aborting build due to invalid input: "release_branch"')
					}
				}
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git remote add bitbucket http://${GIT_USERNAME}:${GIT_PASSWORD}@bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
				}
			}
		}

		stage('Merge') {
			when {
				expression { params.merge == true }
			}
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git merge -X theirs origin/develop"
					sh "git push bitbucket release/${params.release_branch}"
				}
			}
		}

		stage('Update and release the new version') {
			steps {
				script {
					utils.mvn("-B versions:set -DnewVersion=${params.release_version} -P all,dev-env-v3 -e", settings_id)
					utils.mvn("-B deploy -DskipTests -P all,dev-env-v3 -X", settings_id)
				}
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git commit -am \'${params.component} Released with version ${params.release_version}\'"
					sh "git push bitbucket release/${params.release_branch}"
					sh "git tag -a ${params.release_version} -m \'Released with version ${params.release_version}\'"
					sh "git push bitbucket ${params.release_version}"
				}
			}
		}

		stage('Update release with next patch or snapshot version') {
			steps {
				script {
					utils.mvn("-B versions:set -DnewVersion=${params.next_patch_version} -P all,dev-env-v3 -e", settings_id)
					utils.mvn("-B deploy -DskipTests -P all,dev-env-v3", settings_id)
				}
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git commit -am \'${params.component} Next development version updated to ${params.next_patch_version}\'"
					sh "git push bitbucket release/${params.release_branch}"
				}
			}
		}

		stage('Update develop with next snapshot version') {
			when {
				expression { params.merge == true }
			}
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git checkout develop"
				}
				script {
					utils.mvn("-B versions:set -DnewVersion=${params.next_develop_version} -P all,dev-env-v3 -e", settings_id)
					utils.mvn("-B deploy -DskipTests -P all,dev-env-v3", settings_id)
				}
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git commit -am \'${params.component} Next development version updated to ${params.next_develop_version}\'"
					sh "git push bitbucket develop"
				}
			}
		}

		/*stage('Update master to the head of latest tag') {
			steps {
				withCredentials([usernamePassword(credentialsId: 'zapp.jenkins.build', passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
					sh "git checkout master"
					sh "git merge --ff-only refs/tags/${params.release_version}"
					sh "git push bitbucket master"
				}
			}
		}*/
	}
}