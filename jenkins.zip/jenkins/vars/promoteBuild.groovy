@Library('zapp-utilities') _

import com.zapp.utilities
utils = new utilities()

pipeline {

	environment {
		/**
		 * Tools version
		 */
		java_v = 'jdk1.7_151'
		JDK7u17_HOME = tool name: 'jdk1.7_17'
		maven_v = 'Maven 3.0.4'
		settings_id = 'pwba-settings'

		/**
		 * Environment paths
		 */				
		ORACLE_HOME = "/fs01/app/oracle/product/Client11g"
		PATH = "$PATH:$ORACLE_HOME/bin"
		db_test_dir = "$WORKSPACE/properties/test"
		MAVEN_OPTS="-Xmx4g -Xms4g -XX:+UseCompressedOops -XX:MaxPermSize=512m -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"
		vault_password_file = 'vault-password'
		/**
		 * Repo URLs
		 */
		component_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/${params.component}.git"
		ansible_repo_url = "http://bitbucket.vocalink.co.uk/scm/zapp/ansible.git"

		/**
		 * Deploy utils
		 */			
		mw_deployment_util = "middleware-deployment-utility"
		db_deployment_util = "database-deployment-utility"
		wlst_deployment_util = "wlst-deploy-utility"

		/**
		 * Required User Credentials
		 */
		nexus_token = credentials('zapp.nexus.build.token')		
		git_credentials = credentials('zapp.jenkins.build')
		
	}
	
	agent {
		label "${params.agent}"
	}

	options {
		buildDiscarder(logRotator(numToKeepStr: '10'))
		skipDefaultCheckout(true)
		disableConcurrentBuilds()
	}

	tools {
		maven params.maven_v ?: maven_v
		jdk params.java_v ?: java_v
	}

	stages {

		stage('Env Set Up') {
			steps {
				script {
					deleteDir()
					sh "mkdir ${params.component}"
					sh "mkdir ansible"
				}
			}
		}

		stage('Build') {
			when {
				expression { return params.branch }
			}
			steps {
				dir ("${params.component}"){
					git branch: "${params.branch}", credentialsId: 'zapp.jenkins.build', url: component_repo_url
					script {
						if (params.commit) {
							sh "git checkout ${params.commit}"
							currentBuild.description = "Deploy ${params.component} ${params.commit}"
						}
						else {
							currentBuild.description = "Deploy ${params.component} ${params.branch}"
						}
						utils.mvn("clean install -Pall,dev-env-v3,jenkins,dev-test-env-v3-digital,dev-test-env-v4-pbba,update-dev-timeout -DskipTests -Dsun.lang.ClassLoader.allowArraySyntax=true -Dbuild-test-stub -Dweblogic.home=/home/devops/fmw/wlserver_10.3 -Dosb.home=/home/devops/fmw/osb", settings_id)
					}
				}
			}
		}

		stage('Prepare Ansible') {
			steps {
				script {			
					component_version = params.component_version ?: ''
					ansible_branch = params.ansible_branch ?: 'master'
					deploy_path = params.deploy_path ?: '/fs01/app/adapter-deployment/backoffice-sprint-test/zapp-client-adaptor'
					jms_creation = params.create_jms ?: 'false'
					mw_util = utils.utility_version(params.deploy_util_version ?: '', 'deploy_util_version')
					
					if(!params.branch) {
						nexus = "-e nexus_download='true' -e component_version=${component_version}"
						currentBuild.description = "Deploy ${params.component} ${component_version}"
					} else {
						component_version = utils.version(params.component,settings_id)
						nexus = "-e nexus_download='false' -e component_version=${component_version}"
					}
				}
				dir ("$WORKSPACE/ansible") {
					checkout([$class: 'GitSCM', 
						branches: [[name: ansible_branch]],
						doGenerateSubmoduleConfigurations: false, 
						extensions: [
							[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [
							[$class: 'SparseCheckoutPath', path: "/${params.component}/"], 
							[$class: 'SparseCheckoutPath', path: "/${mw_deployment_util}/roles/${mw_deployment_util}"], 
							[$class: 'SparseCheckoutPath', path: "/roles/${db_deployment_util}"]]						
						]],
						submoduleCfg: [],
						userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
					])
					
					sh "mv $WORKSPACE/ansible/${mw_deployment_util}/roles/${mw_deployment_util} $WORKSPACE/ansible/roles/${db_deployment_util} $WORKSPACE/ansible/${component}/roles/"
					sh "rm -rf $WORKSPACE/ansible/${mw_deployment_util} $WORKSPACE/ansible/roles"
					sh "cp $WORKSPACE/${params.component}/properties/*.properties.j2 $WORKSPACE/ansible/${params.component}/roles/${params.component}/templates/ 2>/dev/null || :"					
					
					dir ("$WORKSPACE/ansible/${params.component}") {
						script{
							utils.generate_password('zapp.ansible.vault', vault_password_file)
						}
						withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
							sh """                    
									ansible-playbook -i inv/hosts.yml ${params.component}.yml --vault-password-file ./${vault_password_file} -e env=${params.target_environment} -e workspace=$WORKSPACE \
									-e nexus_user=${git_credentials_usr} -e nexus_pass=${git_credentials_psw} -e download_artifacts=false \
									-e flyway_modules=${params.flyway_modules} \
									-e key1=$apkeyfile -e ssh_user=$ssh_user -e deploy_path=${deploy_path} -e component_name=${params.component} \
									-e properties_version=${params.properties_version} -e jms_creation=${jms_creation} $mw_util $nexus
								"""
						}
						script{
							utils.clean_confidential_data(vault_password_file)
						}
					}
				}
			}
		}
		
		stage('Deploy DB ') {
			when {
					expression {
						return fileExists("$WORKSPACE/properties/flyway/db-deploy-config.properties")
					}
				}
				tools {
					jdk 'jdk1.8_192'
				}
				steps {
					script {
						def db_modules = flyway_modules.split(',')
                        execute_checksum = params.execute_checksum ?: 'No'
                        utils.db_deploy_promote(component,params.target_environment,db_modules,params.flyway_buildtype,execute_checksum,params.branch)
					}
				}
		}
		
		stage('Deploy apps (Middleware Utility)') {
			when {
				expression {
					return fileExists("$WORKSPACE/properties/config-deploy.properties")			
				}
			}
			steps {
				script {		
					jms = ""
					if(params.create_jms == "true") {
						jms = "-Djms_properties_url_1=$WORKSPACE/properties/jms_server1.properties -Djms_properties_url_2=$WORKSPACE/properties/jms_server2.properties"
					}                       
				}
				dir ('ap-middleware-deployment-utility') {
					sh """
                        ./runAPUtil.sh -Dconfig_properties_url=$WORKSPACE/properties/config-deploy.properties ${jms}
                        """
				}
			}
		}
		
		stage ("Deploy App (WLST)") {
			when {
				expression {
					return fileExists("$WORKSPACE/ansible/${params.component}/roles/${params.component}/templates/config-deploy-wlst.properties.j2")			
				}
			}
			stages() {					
				stage("Prepare WLST scripts"){
					steps {
						script {
							component_version = utils.version(params.component,settings_id)
							ansible_branch = params.ansible_branch ?: 'master'
						}
						dir ("$WORKSPACE/ansible") {
							checkout([$class: 'GitSCM', 
								branches: [[name: ansible_branch]],
								doGenerateSubmoduleConfigurations: false, 
								extensions: [
									[$class: 'SparseCheckoutPaths', sparseCheckoutPaths: [[$class: 'SparseCheckoutPath', path: "/${wlst_deployment_util}/"]]							
								]],
								submoduleCfg: [],
								userRemoteConfigs: [[credentialsId: 'zapp.jenkins.build', url: ansible_repo_url]]
							])
						
							dir ("$WORKSPACE/ansible/${wlst_deployment_util}") {
								script{
									utils.generate_password('zapp.ansible.vault', vault_password_file)
								}
								withCredentials([sshUserPrivateKey(credentialsId: 'zapp-apdev', keyFileVariable: 'apkeyfile', passphraseVariable: '', usernameVariable: 'ssh_user')]) {
									sh """
									ansible-playbook -i inv/hosts.yml wlst-deploy-utility.yml --vault-password-file ./${vault_password_file} -e env=${params.target_environment} -e component_version=${component_version} -e workspace=$WORKSPACE\
									-e nexus_download="false" -e component_name=${params.component} -e component_target_path="$WORKSPACE/${params.component}/assembly"
									"""
								}
								script{
									utils.clean_confidential_data(vault_password_file)
								}
							}
						}
					}
				}
				
				stage("Deploy App (WLST)") {
					steps {
						dir ("scripts") {
						sh """
							chmod +x $WORKSPACE/scripts/wlst_deploy.sh
							./wlst_deploy.sh
						"""
						}
					}
				}
			}
		}
		
	}
	post {
		always {
			script{
				utils.clean_confidential_data('all')
			}
		}
	}
	
}