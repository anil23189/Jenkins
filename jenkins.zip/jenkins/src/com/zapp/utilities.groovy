package com.zapp

    def mvn(goal, settings_id) {
        configFileProvider(
	    [configFile(fileId: "${settings_id}", variable: 'settings_file')]) {
                sh "mvn -s ${settings_file} ${goal}"
	    }
	}
    def utility_version(util_version, ansible_param) {
        if (!util_version?.trim()) {
            deploy_util = ""
        }
        else {
            deploy_util = "-e $ansible_param=$util_version"
        }
        return deploy_util
    }

    def cleanup(component, settings_id){
        dir(component){
            script{
                    mvn("clean -q", settings_id)
            }
        }
        if (fileExists('ap-database-deployment-utility')){
            dir ('ap-database-deployment-utility') {
                deleteDir()
            }
        }
        if (fileExists('ap-middleware-deployment-utility')){
            dir ('ap-middleware-deployment-utility') {
                deleteDir()
            }
        }

    }
	
	def version(component,settings_id){
		dir("${WORKSPACE}/${component}")
		{
			configFileProvider(
				[configFile(fileId: "${settings_id}", variable: 'settings_file')]) {
						return sh (script : "mvn -s ${settings_file} help:evaluate -Dexpression=project.version -q -DforceStdout", returnStdout: true)
				}
		}
	}
	
    def version(component){
        return(readFile("${WORKSPACE}/${component}/pom.xml") =~ '<version>(.+)</version>')[0][1]
    }
	def db_deploy(component,dir_path,db_env,db_modules,properties_path,flyway_buildtype="",execute_checksum="",branch=""){
        db_modules.each { item ->
        dir ("$dir_path/${item}"){
				deploy_views(item,dir_path,component,db_env,properties_path,flyway_buildtype,execute_checksum)
				deploy_db_keys(item,db_env,properties_path)
				deploy_interschema_synonyms(item,db_env,properties_path,branch)
				deploy_packages(item,db_env,properties_path)
				deploy_jobs(item,db_env,properties_path)
				deploy_grants(item,db_env,properties_path)
				deploy_cb_synonyms(item,db_env,properties_path,branch)
			}
		}
    }
	def db_deploy_promote(component,db_env,db_modules,flyway_buildtype,execute_checksum,branch=""){
		def properties_path = "$WORKSPACE/properties/flyway"
		def dir_path = "$WORKSPACE/$component/database"
		if(!fileExists(dir_path)){
		    dir_path = "$WORKSPACE/$component"
		}
		if(!branch){
			dir_path = "$WORKSPACE/flyway/work"
		}
		db_deploy(component,dir_path,db_env,db_modules,properties_path,flyway_buildtype,execute_checksum,branch)
	}
	def deploy_views(module,dir_path,component,db_env,properties_path,flyway_buildtype="",execute_checksum=""){
		if(flyway_buildtype == "full" || db_env.contains("cb")){
			db_migrate("$properties_path/${module}-flyway-dbscripts-views-${db_env}.conf","clean")
		}
		db_migrate("$properties_path/${module}-flyway-dbscripts-views-${db_env}.conf","baseline")
		if(flyway_buildtype == "incremental"){
			if(execute_checksum == "Yes"){
				sh """
					echo script.location=$dir_path/${module}/resources/approved/db_objects/scripts/ >>  $properties_path/${module}-checksum-${db_env}.conf
				"""
				sh "java -jar $WORKSPACE/flyway/utility/checksum.jar propfile=$properties_path/${module}-checksum-${db_env}.conf"
			}
			db_migrate("$properties_path/${module}-flyway-dbscripts-views-${db_env}.conf","repair")
		}
		db_migrate("$properties_path/${module}-flyway-dbscripts-views-${db_env}.conf","migrate","-Dflyway.outOfOrder=true -Dflyway.ignoreMissingMigrations=true")
	}
	def deploy_db_keys(module,db_env,properties_path){
		if(db_env.contains("cb") && fileExists("$properties_path/${module}-flyway-db-key-${db_env}.conf")){
			db_migrate("$properties_path/${module}-flyway-db-key-${db_env}.conf","migrate","-Dflyway.outOfOrder=true -Dflyway.ignoreMissingMigrations=true")
		}
	}
	def deploy_interschema_synonyms(module,db_env,properties_path,branch=""){
		if(fileExists("$properties_path/${module}-flyway-interschema_synonym-${db_env}.conf")){
			if(!branch && !db_env.contains("cb")){
				sh """
					echo -e '\nsynomnyms.script.location=$WORKSPACE/flyway/work/${module}/resources/unapproved/deployable/interschema_synonym' >> $properties_path/${module}-flyway-interschema_synonym-${db_env}.conf
				"""
			}
			sh "java -jar $WORKSPACE/flyway/utility/synonyms.jar propfile=$properties_path/${module}-flyway-interschema_synonym-${db_env}.conf"
		}
	}
	def deploy_packages(module,db_env,properties_path){
		db_migrate("$properties_path/${module}-flyway-package-specs-${db_env}.conf","migrate")
		db_migrate("$properties_path/${module}-flyway-package-bodies-${db_env}.conf","migrate")
	}
	def deploy_jobs(module,db_env,properties_path){
		if(fileExists("$properties_path/${module}-flyway-jobs-${db_env}.conf")){
			db_migrate("$properties_path/${module}-flyway-jobs-${db_env}.conf","migrate")
		}
	}
	def deploy_grants(module,db_env,properties_path){
		if(fileExists("$properties_path/${module}-grants-${db_env}.conf")){
			db_migrate("$properties_path/${module}-grants-${db_env}.conf","migrate")
		}
		if(fileExists("$properties_path/${module}-queue-grants-${db_env}.conf")){
			db_migrate("$properties_path/${module}-queue-grants-${db_env}.conf","migrate")
		}
	}
	def deploy_cb_synonyms(module,db_env,properties_path,branch=""){
		if(!branch && !db_env.contains("cb")){
			sh """
				echo -e '\nsynomnyms.script.location=$WORKSPACE/flyway/work/${module}/resources/unapproved/deployable/cb_synonym' >> $properties_path/${module}-flyway-cb_synonym-${db_env}.conf
			"""
		}
		sh "java -jar $WORKSPACE/flyway/utility/synonyms.jar propfile=$properties_path/${module}-flyway-cb_synonym-${db_env}.conf"
		if(fileExists("$properties_path/${module}-flyway-apnifiextractuser_synonyms-${db_env}.conf")){
			sh "java -jar $WORKSPACE/flyway/utility/synonyms.jar propfile=$properties_path/${module}-flyway-apnifiextractuser_synonyms-${db_env}.conf"
		}
		if(fileExists("$properties_path/${module}-flyway-appbasisbatchuser_synonyms-${db_env}.conf")){
			sh "java -jar $WORKSPACE/flyway/utility/synonyms.jar propfile=$properties_path/${module}-flyway-appbasisbatchuser_synonyms-${db_env}.conf"
		}
		if(fileExists("$properties_path/${module}-flyway-apsecphsmuser_synonyms-${db_env}.conf")){
			sh "java -jar $WORKSPACE/flyway/utility/synonyms.jar propfile=$properties_path/${module}-flyway-apsecphsmuser_synonyms-${db_env}.conf"
		}
	}
	def db_migrate(configFiles,action,params=""){
		mvn("-Dflyway.configFiles=$configFiles $params flyway:$action -e", settings_id)
	}
	def generate_password(credentials_id, file_name){
		withCredentials([string(credentialsId: credentials_id, variable: 'passphrase')]) {
			   sh "touch $file_name"
			   sh "echo ${passphrase} > $file_name"
		}
	}
	def clean_confidential_data(file_name){
		if(file_name == "all"){
			dir ("$WORKSPACE/properties") {
				echo "Cleaning data"
				FILES = sh (script: 'find . -type f -print0', returnStdout: true).trim()
				if(FILES?.trim()) {
					sh """
					   find . -type f -print0 | xargs -0 sed -i /password/Id
					"""
				}
			}
		}else{
			sh """
				rm $file_name
			"""
		}
	}
	def vulnerability_check(property_file){
		def artefacts = read_property(property_file,'artefacts').split(',')
		artefacts.each { item ->
			def info = read_property(property_file, item).split(',')
			def nexus_app = info[0]
			def pattern = info[1]
			nexusiq(nexus_app, pattern, "build")
		}
	}
	def read_property(property_file,property){
		def property_key = property.replaceAll("\\s","")
		def value = sh returnStdout: true, script: "cat $property_file | grep $property_key= | sed -e \"s/.*=//g\" -e \"s/['| ]//g\" "
		return value						
	}
	def nexusiq(nexus_app,pattern,policy_check_stage){
		dir("$WORKSPACE"){
			try {
				def policyEvaluation = nexusPolicyEvaluation advancedProperties: '', failBuildOnNetworkError: false, iqApplication: selectedApplication(nexus_app), iqScanPatterns: [[scanPattern: pattern], [scanPattern: '']], iqStage: policy_check_stage, jobCredentialsId: ''
			} catch (error) {
				def policyEvaluation = error.policyEvaluation
				throw error
			}
		}
	}